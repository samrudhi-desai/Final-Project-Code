package com.example.viewpager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    EditText edittext;
    ImageButton add;
    ImageButton save;
    ImageButton load;
    TextView textview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        edittext =(EditText)findViewById(R.id.edittext);
        save = (ImageButton)findViewById(R.id.save);
        load = (ImageButton)findViewById(R.id.load);
        add =(ImageButton)findViewById(R.id.add);
        textview = (TextView)findViewById(R.id.check);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edittext.getText().toString();
                textview.setText(name);
            }
        });
    }
    }
